import { Component, OnInit } from '@angular/core';
import {  SrvBusquedaService} from './services/srv-busqueda.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(private SrvEliService:SrvBusquedaService){
    
  }
  ngOnInit(){
    this.SrvEliService.busquedaDeUsuarios('Eliezer').then((response)=>{
      alert("total:"+response.total_count + "\n"+
      "El priemer usuario es:"+response.items[1].login+ "\n"+
      "html_url: "+response.items[1].html_url) ;
    }, (error)=>{
      alert("Error" + error.statusText)
    })  
  }
  title = 'titulo'
}
